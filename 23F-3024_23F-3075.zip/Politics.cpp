#include "KingdomGame.h"

Politics::Politics(SocialStructure* social, Military* military) : _taxPolicy(BASE_TAX_RATE), _militarySupport(0.5), _leaderPersonality("Balanced") {}

void Politics::update() {}

void Politics::save(ofstream& out) {
    out << "taxPolicy:" << _taxPolicy << "\n";
}

void Politics::load(ifstream& in) {
    in >> _taxPolicy;
}

void Politics::handleEvent(const string& eventType) {}

string Politics::getStatus() const {
    return "Politics: TaxPolicy=" + to_string(_taxPolicy * 100) + "%\n";
}

double Politics::getTaxPolicy() const {
    return _taxPolicy;
}

double Politics::getMilitarySupport() const {
    return _militarySupport;
}

string Politics::getLeaderPersonality() const {
    return _leaderPersonality;
}
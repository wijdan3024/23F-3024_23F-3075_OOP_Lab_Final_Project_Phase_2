#include "KingdomGame.h"

// Explicit template instantiation
template class Resources<int>;

template <typename T>
Resources<T>::Resources() : _food(1000), _wood(1000), _stone(1000) {}

template <typename T>
void Resources<T>::update() {
    _food += static_cast<T>(BASE_RESOURCE_PRODUCTION);
}

template <typename T>
void Resources<T>::save(ofstream& out) {
    out << "food:" << _food << "\n";
}

template <typename T>
void Resources<T>::load(ifstream& in) {
    in >> _food;
}

template <typename T>
void Resources<T>::handleEvent(const string& eventType) {}

template <typename T>
string Resources<T>::getStatus() const {
    return "Resources: Food=" + to_string(_food) + "\n";
}

template <typename T>
T Resources<T>::getResource(const string& type) const {
    if (type == "Food") return _food;
    if (type == "Wood") return _wood;
    if (type == "Stone") return _stone;
    return 0;
}

template <typename T>
void Resources<T>::adjustResource(const string& type, T amount) {
    if (type == "Food") _food += amount;
    if (type == "Wood") _wood += amount;
    if (type == "Stone") _stone += amount;
}
#include "KingdomGame.h"

Map::Map(int id) : _kingdomId(id), _x(getRandom(0, GRID_SIZE - 1)), _y(getRandom(0, GRID_SIZE - 1)) {}

void Map::update() {}

void Map::save(ofstream& out) {
    out << "x:" << _x << ",y:" << _y << "\n";
}

void Map::load(ifstream& in) {
    in >> _x >> _y;
}

void Map::handleEvent(const string& eventType) {}

string Map::getStatus() const {
    return "Map: (" + to_string(_x) + "," + to_string(_y) + ")\n";
}

bool Map::move(int newX, int newY) {
    if (newX >= 0 && newX < GRID_SIZE && newY >= 0 && newY < GRID_SIZE) {
        _x = newX;
        _y = newY;
        return true;
    }
    return false;
}

int Map::getX() const {
    return _x;
}

int Map::getY() const {
    return _y;
}

bool Map::isAdjacent(int x, int y) const {
    return abs(_x - x) <= 1 && abs(_y - y) <= 1;
}
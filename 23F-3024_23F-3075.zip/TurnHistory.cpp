#include "KingdomGame.h"

TurnHistory::TurnHistory(int t, const string& a, const string& d) : turn(t), action(a), details(d) {}
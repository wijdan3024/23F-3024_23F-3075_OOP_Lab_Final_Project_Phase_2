#include "KingdomGame.h"

// KingdomManager class
class KingdomManager {
private:
    Kingdom* _kingdoms[MAX_KINGDOMS];
    int _kingdomCount;
public:
    KingdomManager() : _kingdomCount(0) {
        for (int i = 0; i < MAX_KINGDOMS; i++) _kingdoms[i] = nullptr;
    }

    ~KingdomManager() {
        for (int i = 0; i < _kingdomCount; i++) delete _kingdoms[i];
    }

    void addKingdom() {
        if (_kingdomCount < MAX_KINGDOMS) {
            _kingdoms[_kingdomCount] = new Kingdom(_kingdomCount);
            _kingdomCount++;
        }
    }

    Kingdom* getKingdom(int id) {
        if (id >= 0 && id < _kingdomCount) return _kingdoms[id];
        return nullptr;
    }

    void run() {
        srand(static_cast<unsigned>(time(nullptr)));
        addKingdom();
        addKingdom();
        addKingdom();
        int currentKingdomId = 0;

        while (true) {
            Kingdom* currentKingdom = getKingdom(currentKingdomId);
            if (!currentKingdom) {
                currentKingdomId = (currentKingdomId + 1) % _kingdomCount;
                continue;
            }
            cout << "          *************************************************\n";
                cout << GREEN << "             Welcome to Stronghold: Core Kingdom Engine\n" << RESET;
                cout << "          *************************************************\n";
            cout << "\n";
            cout << MAGENTA << "====================================\n";
            cout << "|| " << CYAN << "   Stronghold: Kingdom " << currentKingdomId << " Menu   " << MAGENTA << " ||\n";
            cout << "====================================\n" << RESET;
            cout << GREEN << "| 1. View Kingdom Status          |\n" << RESET;
            cout << CYAN << "| 2. Manage Army                  |\n" << RESET;
            cout << GREEN << "| 3. Adjust Taxes                 |\n" << RESET;
            cout << CYAN << "| 4. Bank Operations              |\n" << RESET;
            cout << GREEN << "| 5. Process Next Month           |\n" << RESET;
            cout << CYAN << "| 6. Save/Load Game               |\n" << RESET;
            cout << GREEN << "| 7. View Leader Personality      |\n" << RESET;
            cout << CYAN << "| 8. Communication                |\n" << RESET;
            cout << GREEN << "| 9. Alliances                    |\n" << RESET;
            cout << CYAN << "| 10. Market Operations           |\n" << RESET;
            cout << GREEN << "| 11. War and Conflict            |\n" << RESET;
            cout << CYAN << "| 12. Map and Movement            |\n" << RESET;
            cout << GREEN << "| 13. Switch Kingdom              |\n" << RESET;
            cout << CYAN << "| 14. Exit                        |\n" << RESET;
            cout << MAGENTA << "====================================\n" << RESET;
            cout << "Please Enter Your Choice: ";

            int choice;
            if (!(cin >> choice)) {
                cin.clear();
                cin.ignore(10000, '\n');
                cout << RED << "Invalid input! Please enter a number.\n" << RESET;
                continue;
            }

            switch (choice) {
            case 1:
                currentKingdom->displayStatus();
                break;

            case 2: {
                cout << MAGENTA << "====================================\n";
                cout << "|| " << CYAN << "   Army Management Menu     " << MAGENTA << " ||\n";
                cout << "====================================\n" << RESET;
                cout << GREEN << "| 1. Recruit Soldiers             |\n" << RESET;
                cout << CYAN << "| 2. Pay Soldiers                 |\n" << RESET;
                cout << GREEN << "| 3. Back                         |\n" << RESET;
                cout << "Enter choice: ";
                int armyChoice;
                if (!(cin >> armyChoice)) {
                    cin.clear();
                    cin.ignore(10000, '\n');
                    cout << RED << "Invalid input!\n" << RESET;
                    continue;
                }
                switch (armyChoice) {
                case 1: {
                    cout << "Enter number of soldiers to recruit (max " << currentKingdom->getPopulation()->getPopulationSize() / 10 << "): ";
                    int count;
                    if (!(cin >> count) || count < 0) {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << RED << "Invalid input!\n" << RESET;
                    }
                    else if (currentKingdom->getMilitary()->recruit(count)) {
                        currentKingdom->addToHistory("Recruit Soldiers", "Recruited " + to_string(count) + " soldiers");
                        cout << GREEN << "Recruited " << count << " soldiers.\n" << RESET;
                    }
                    else {
                        cout << RED << "Not enough population or invalid number!\n" << RESET;
                    }
                    break;
                }
                case 2:
                    if (currentKingdom->getMilitary()->paySoldiers(currentKingdom->getEconomy())) {
                        currentKingdom->addToHistory("Pay Soldiers", "Paid soldiers");
                        cout << GREEN << "Soldiers paid.\n" << RESET;
                    }
                    else {
                        cout << RED << "Not enough gold!\n" << RESET;
                    }
                    break;
                case 3:
                    break;
                default:
                    cout << RED << "Invalid choice!\n" << RESET;
                }
                break;
            }

            case 3: {
                cout << "Enter new tax rate (0.0 to 0.5): ";
                double taxRate;
                if (!(cin >> taxRate) || taxRate < 0.0 || taxRate > 0.5) {
                    cin.clear();
                    cin.ignore(10000, '\n');
                    cout << RED << "Invalid tax rate!\n" << RESET;
                }
                else {
                    currentKingdom->getEconomy()->setTaxRate(taxRate);
                    currentKingdom->addToHistory("Adjust Taxes", "Set tax rate to " + to_string(taxRate * 100) + "%");
                    cout << GREEN << "Tax rate set to " << taxRate * 100 << "%.\n" << RESET;
                }
                break;
            }

            case 4: {
                cout << MAGENTA << "====================================\n";
                cout << "|| " << CYAN << "   Bank Operations Menu     " << MAGENTA << " ||\n";
                cout << "====================================\n" << RESET;
                cout << GREEN << "| 1. Take Loan                    |\n" << RESET;
                cout << CYAN << "| 2. Conduct Audit                |\n" << RESET;
                cout << GREEN << "| 3. Back                         |\n" << RESET;
                cout << "Enter choice: ";
                int bankChoice;
                if (!(cin >> bankChoice)) {
                    cin.clear();
                    cin.ignore(10000, '\n');
                    cout << RED << "Invalid input!\n" << RESET;
                    continue;
                }
                switch (bankChoice) {
                case 1: {
                    cout << "Enter loan amount: ";
                    double loanAmount;
                    if (!(cin >> loanAmount) || loanAmount <= 0) {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << RED << "Invalid loan amount!\n" << RESET;
                    }
                    else if (currentKingdom->getBanking()->takeLoan(loanAmount, currentKingdom->getEconomy())) {
                        currentKingdom->addToHistory("Take Loan", "Took loan of " + to_string(loanAmount) + " gold");
                        cout << GREEN << "Loan of " << loanAmount << " gold taken.\n" << RESET;
                    }
                    else {
                        cout << RED << "Failed to take loan!\n" << RESET;
                    }
                    break;
                }
                case 2:
                    currentKingdom->getBanking()->audit();
                    currentKingdom->addToHistory("Audit", "Conducted bank audit");
                    cout << GREEN << "Audit conducted, corruption reduced.\n" << RESET;
                    break;
                case 3:
                    break;
                default:
                    cout << RED << "Invalid choice!\n" << RESET;
                }
                break;
            }

            case 5:
                currentKingdom->update();
                currentKingdom->addToHistory("Next Month", "Processed turn " + to_string(currentKingdom->getTurn()));
                cout << GREEN << "Month processed for Kingdom " << currentKingdomId << ".\n" << RESET;
                break;

            case 6: {
                cout << MAGENTA << "====================================\n";
                cout << "|| " << CYAN << "   Save/Load Menu           " << MAGENTA << " ||\n";
                cout << "====================================\n" << RESET;
                cout << GREEN << "| 1. Save Game                    |\n" << RESET;
                cout << CYAN << "| 2. Load Game                    |\n" << RESET;
                cout << GREEN << "| 3. Back                         |\n" << RESET;
                cout << "Enter choice: ";
                int saveChoice;
                if (!(cin >> saveChoice)) {
                    cin.clear();
                    cin.ignore(10000, '\n');
                    cout << RED << "Invalid input!\n" << RESET;
                    continue;
                }
                switch (saveChoice) {
                case 1:
                    currentKingdom->saveGame();
                    cout << GREEN << "Game saved for Kingdom " << currentKingdomId << ".\n" << RESET;
                    break;
                case 2:
                    currentKingdom->loadGame();
                    cout << GREEN << "Game loaded for Kingdom " << currentKingdomId << ".\n" << RESET;
                    break;
                case 3:
                    break;
                default:
                    cout << RED << "Invalid choice!\n" << RESET;
                }
                break;
            }

            case 7:
                currentKingdom->displayLeaderPersonality();
                break;

            case 8: {
                cout << MAGENTA << "====================================\n";
                cout << "|| " << CYAN << "   Communication Menu        " << MAGENTA << " ||\n";
                cout << "====================================\n" << RESET;
                cout << GREEN << "| 1. Send Message                 |\n" << RESET;
                cout << CYAN << "| 2. View Messages                |\n" << RESET;
                cout << GREEN << "| 3. Back                         |\n" << RESET;
                cout << "Enter choice: ";
                int commChoice;
                if (!(cin >> commChoice)) {
                    cin.clear();
                    cin.ignore(10000, '\n');
                    cout << RED << "Invalid input!\n" << RESET;
                    continue;
                }
                switch (commChoice) {
                case 1: {
                    cout << "Enter recipient Kingdom ID (0 to " << _kingdomCount - 1 << "): ";
                    int recipientId;
                    if (!(cin >> recipientId) || recipientId < 0 || recipientId >= _kingdomCount || recipientId == currentKingdomId) {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << RED << "Invalid Kingdom ID!\n" << RESET;
                    }
                    else {
                        cin.ignore();
                        cout << "Enter message: ";
                        string message;
                        getline(cin, message);
                        if (currentKingdom->getCommunication()->sendMessage(currentKingdomId, recipientId, message)) {
                            currentKingdom->addToHistory("Send Message", "Sent message to Kingdom " + to_string(recipientId));
                            cout << GREEN << "Message sent to Kingdom " << recipientId << ".\n" << RESET;
                        }
                        else {
                            cout << RED << "Failed to send message!\n" << RESET;
                        }
                    }
                    break;
                }
                case 2:
                    cout << currentKingdom->getCommunication()->getStatus();
                    currentKingdom->addToHistory("View Messages", "Viewed communication status");
                    break;
                case 3:
                    break;
                default:
                    cout << RED << "Invalid choice!\n" << RESET;
                }
                break;
            }

            case 9: {
                cout << MAGENTA << "====================================\n";
                cout << "|| " << CYAN << "   Alliances Menu           " << MAGENTA << " ||\n";
                cout << "====================================\n" << RESET;
                cout << GREEN << "| 1. Propose Treaty               |\n" << RESET;
                cout << CYAN << "| 2. Break Treaty                 |\n" << RESET;
                cout << GREEN << "| 3. View Alliances               |\n" << RESET;
                cout << CYAN << "| 4. Back                         |\n" << RESET;
                cout << "Enter choice: ";
                int allianceChoice;
                if (!(cin >> allianceChoice)) {
                    cin.clear();
                    cin.ignore(10000, '\n');
                    cout << RED << "Invalid input!\n" << RESET;
                    continue;
                }
                switch (allianceChoice) {
                case 1: {
                    cout << "Enter Kingdom ID to propose treaty (0 to " << _kingdomCount - 1 << "): ";
                    int otherKingdomId;
                    if (!(cin >> otherKingdomId) || otherKingdomId < 0 || otherKingdomId >= _kingdomCount || otherKingdomId == currentKingdomId) {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << RED << "Invalid Kingdom ID!\n" << RESET;
                    }
                    else {
                        cout << "Enter treaty type (Alliance/Treaty): ";
                        string treatyType;
                        cin >> treatyType;
                        if (treatyType != "Alliance" && treatyType != "Treaty") {
                            cout << RED << "Invalid treaty type! Use 'Alliance' or 'Treaty'.\n" << RESET;
                        }
                        else if (currentKingdom->getAlliance()->proposeTreaty(otherKingdomId, treatyType)) {
                            currentKingdom->addToHistory("Propose Treaty", "Proposed " + treatyType + " with Kingdom " + to_string(otherKingdomId));
                            cout << GREEN << treatyType << " proposed with Kingdom " << otherKingdomId << ".\n" << RESET;
                        }
                        else {
                            cout << RED << "Failed to propose treaty!\n" << RESET;
                        }
                    }
                    break;
                }
                case 2: {
                    cout << "Enter Kingdom ID to break treaty (0 to " << _kingdomCount - 1 << "): ";
                    int otherKingdomId;
                    if (!(cin >> otherKingdomId) || otherKingdomId < 0 || otherKingdomId >= _kingdomCount || otherKingdomId == currentKingdomId) {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << RED << "Invalid Kingdom ID!\n" << RESET;
                    }
                    else if (currentKingdom->getAlliance()->breakTreaty(otherKingdomId, currentKingdom->getSocialStructure())) {
                        currentKingdom->addToHistory("Break Treaty", "Broke treaty with Kingdom " + to_string(otherKingdomId));
                        cout << GREEN << "Treaty broken with Kingdom " << otherKingdomId << ".\n" << RESET;
                    }
                    else {
                        cout << RED << "No active treaty to break!\n" << RESET;
                    }
                    break;
                }
                case 3:
                    cout << currentKingdom->getAlliance()->getStatus();
                    currentKingdom->addToHistory("View Alliances", "Viewed alliance status");
                    break;
                case 4:
                    break;
                default:
                    cout << RED << "Invalid choice!\n" << RESET;
                }
                break;
            }

            case 10: {
                cout << MAGENTA << "====================================\n";
                cout << "|| " << CYAN << "   Market Operations Menu   " << MAGENTA << " ||\n";
                cout << "====================================\n" << RESET;
                cout << GREEN << "| 1. Trade Resources              |\n" << RESET;
                cout << CYAN << "| 2. Smuggle Resources            |\n" << RESET;
                cout << GREEN << "| 3. Impose Embargo               |\n" << RESET;
                cout << CYAN << "| 4. View Market Status           |\n" << RESET;
                cout << GREEN << "| 5. Back                         |\n" << RESET;
                cout << "Enter choice: ";
                int marketChoice;
                if (!(cin >> marketChoice)) {
                    cin.clear();
                    cin.ignore(10000, '\n');
                    cout << RED << "Invalid input!\n" << RESET;
                    continue;
                }
                switch (marketChoice) {
                case 1:
                case 2: {
                    cout << "Enter buyer Kingdom ID (0 to " << _kingdomCount - 1 << "): ";
                    int buyerId;
                    if (!(cin >> buyerId) || buyerId < 0 || buyerId >= _kingdomCount || buyerId == currentKingdomId) {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << RED << "Invalid Kingdom ID!\n" << RESET;
                        break;
                    }
                    cout << "Enter resource (Food/Wood/Stone): ";
                    string resource;
                    cin >> resource;
                    if (resource != "Food" && resource != "Wood" && resource != "Stone") {
                        cout << RED << "Invalid resource!\n" << RESET;
                        break;
                    }
                    cout << "Enter quantity: ";
                    int quantity;
                    if (!(cin >> quantity) || quantity <= 0) {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << RED << "Invalid quantity!\n" << RESET;
                        break;
                    }
                    cout << "Enter price: ";
                    int price;
                    if (!(cin >> price) || price <= 0) {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << RED << "Invalid price!\n" << RESET;
                        break;
                    }
                    Kingdom* buyerKingdom = getKingdom(buyerId);
                    if (!buyerKingdom) {
                        cout << RED << "Buyer kingdom not found!\n" << RESET;
                        break;
                    }
                    bool success = false;
                    if (marketChoice == 1) {
                        success = currentKingdom->getMarket()->trade(
                            buyerId, resource, quantity, price,
                            currentKingdom->getResources(), buyerKingdom->getResources(),
                            currentKingdom->getEconomy(), buyerKingdom->getEconomy()
                        );
                    }
                    else {
                        success = currentKingdom->getMarket()->smuggle(
                            buyerId, resource, quantity, price,
                            currentKingdom->getResources(), buyerKingdom->getResources(),
                            currentKingdom->getEconomy(), buyerKingdom->getEconomy(),
                            currentKingdom->getSocialStructure()
                        );
                    }
                    if (success) {
                        currentKingdom->addToHistory(marketChoice == 1 ? "Trade" : "Smuggle",
                            (marketChoice == 1 ? "Traded " : "Smuggled ") + to_string(quantity) + " " + resource + " to Kingdom " + to_string(buyerId));
                        cout << GREEN << (marketChoice == 1 ? "Trade" : "Smuggle") << " successful!\n" << RESET;
                    }
                    else {
                        cout << RED << (marketChoice == 1 ? "Trade" : "Smuggle") << " failed!\n" << RESET;
                    }
                    break;
                }
                case 3: {
                    cout << "Enter Kingdom ID to impose embargo (0 to " << _kingdomCount - 1 << "): ";
                    int embargoId;
                    if (!(cin >> embargoId) || embargoId < 0 || embargoId >= _kingdomCount || embargoId == currentKingdomId) {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << RED << "Invalid Kingdom ID!\n" << RESET;
                    }
                    else if (currentKingdom->getMarket()->addEmbargo(embargoId)) {
                        currentKingdom->addToHistory("Impose Embargo", "Imposed embargo on Kingdom " + to_string(embargoId));
                        cout << GREEN << "Embargo imposed on Kingdom " << embargoId << ".\n" << RESET;
                    }
                    else {
                        cout << RED << "Failed to impose embargo!\n" << RESET;
                    }
                    break;
                }
                case 4:
                    cout << currentKingdom->getMarket()->getStatus();
                    currentKingdom->addToHistory("View Market", "Viewed market status");
                    break;
                case 5:
                    break;
                default:
                    cout << RED << "Invalid choice!\n" << RESET;
                }
                break;
            }

            case 11: {
                cout << MAGENTA << "====================================\n";
                cout << "|| " << CYAN << "   War and Conflict Menu    " << MAGENTA << " ||\n";
                cout << "====================================\n" << RESET;
                cout << GREEN << "| 1. Attack Kingdom               |\n" << RESET;
                cout << CYAN << "| 2. Back                         |\n" << RESET;
                cout << "Enter choice: ";
                int warChoice;
                if (!(cin >> warChoice)) {
                    cin.clear();
                    cin.ignore(10000, '\n');
                    cout << RED << "Invalid input!\n" << RESET;
                    continue;
                }
                switch (warChoice) {
                case 1: {
                    cout << "Enter target Kingdom ID (0 to " << _kingdomCount - 1 << "): ";
                    int targetId;
                    if (!(cin >> targetId) || targetId < 0 || targetId >= _kingdomCount || targetId == currentKingdomId) {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << RED << "Invalid Kingdom ID!\n" << RESET;
                        break;
                    }
                    Kingdom* targetKingdom = getKingdom(targetId);
                    if (!targetKingdom) {
                        cout << RED << "Target kingdom not found!\n" << RESET;
                        break;
                    }
                    if (!currentKingdom->getMap()->isAdjacent(targetKingdom->getMap()->getX(), targetKingdom->getMap()->getY())) {
                        cout << RED << "Target kingdom is not adjacent!\n" << RESET;
                        break;
                    }
                    bool isBetrayal = currentKingdom->getAlliance()->isAllied(targetId);
                    if (currentKingdom->getMilitary()->attack(
                        targetKingdom->getMilitary(),
                        isBetrayal,
                        currentKingdom->getSocialStructure(),
                        currentKingdom->getResources()
                    )) {
                        currentKingdom->addToHistory("Attack", "Attacked Kingdom " + to_string(targetId) + " and won");
                        cout << GREEN << "Victory against Kingdom " << targetId << "!\n" << RESET;
                    }
                    else {
                        currentKingdom->addToHistory("Attack", "Attacked Kingdom " + to_string(targetId) + " and lost");
                        cout << RED << "Defeated by Kingdom " << targetId << "!\n" << RESET;
                    }
                    break;
                }
                case 2:
                    break;
                default:
                    cout << RED << "Invalid choice!\n" << RESET;
                }
                break;
            }

            case 12: {
                cout << MAGENTA << "====================================\n";
                cout << "|| " << CYAN << "   Map and Movement Menu    " << MAGENTA << " ||\n";
                cout << "====================================\n" << RESET;
                cout << GREEN << "| 1. Move Kingdom                 |\n" << RESET;
                cout << CYAN << "| 2. View Map                     |\n" << RESET;
                cout << GREEN << "| 3. Back                         |\n" << RESET;
                cout << "Enter choice: ";
                int mapChoice;
                if (!(cin >> mapChoice)) {
                    cin.clear();
                    cin.ignore(10000, '\n');
                    cout << RED << "Invalid input!\n" << RESET;
                    continue;
                }
                switch (mapChoice) {
                case 1: {
                    cout << "Enter new X coordinate (0 to " << GRID_SIZE - 1 << "): ";
                    int newX;
                    if (!(cin >> newX) || newX < 0 || newX >= GRID_SIZE) {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << RED << "Invalid X coordinate!\n" << RESET;
                        break;
                    }
                    cout << "Enter new Y coordinate (0 to " << GRID_SIZE - 1 << "): ";
                    int newY;
                    if (!(cin >> newY) || newY < 0 || newY >= GRID_SIZE) {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << RED << "Invalid Y coordinate!\n" << RESET;
                        break;
                    }
                    if (currentKingdom->getMap()->move(newX, newY)) {
                        currentKingdom->addToHistory("Move", "Moved to (" + to_string(newX) + "," + to_string(newY) + ")");
                        cout << GREEN << "Moved to (" << newX << "," << newY << ").\n" << RESET;
                    }
                    else {
                        cout << RED << "Failed to move!\n" << RESET;
                    }
                    break;
                }
                case 2:
                    cout << currentKingdom->getMap()->getStatus();
                    currentKingdom->addToHistory("View Map", "Viewed map status");
                    break;
                case 3:
                    break;
                default:
                    cout << RED << "Invalid choice!\n" << RESET;
                }
                break;
            }

            case 13:
                currentKingdomId = (currentKingdomId + 1) % _kingdomCount;
                cout << GREEN << "Switched to Kingdom " << currentKingdomId << ".\n" << RESET;
                break;

            case 14:
                cout << GREEN << "Exiting game. Goodbye!\n" << RESET;
                return;

            default:
                cout << RED << "Invalid choice! Please select a valid option.\n" << RESET;
            }
        }
    }
};

// Main function
int main() {
    KingdomManager manager;
    manager.run();
    system("pause");
}
#include "KingdomGame.h"

PopulationException::PopulationException(const string& msg) : message(msg) {}
const char* PopulationException::what() const noexcept { return message.c_str(); }

Population::Population() : _populationSize(1000), _happiness(0.7), _health(0.8) {}

void Population::update() {
    int growth = static_cast<int>(8.0);
    _populationSize += growth;
    if (_populationSize > MAX_POPULATION) _populationSize = MAX_POPULATION;

    if (_happiness < 0.3) {
        int loss = getRandom(10, 50);
        try {
            reducePopulation(loss);
        }
        catch (const PopulationException& e) {
            cout << RED << "Error: " << e.what() << RESET << endl;
            _populationSize = 0;
        }
    }
    if (_populationSize < 0) _populationSize = 0;
}

void Population::save(ofstream& out) {
    if (!out.is_open()) return;
    out << "populationSize:" << _populationSize << ",happiness:" << _happiness << ",health:" << _health << "\n";
}

void Population::load(ifstream& in) {
    if (!in.is_open()) return;
    string line;
    if (getline(in, line)) {
        stringstream ss(line);
        string key, value;
        while (getline(ss, key, ':') && getline(ss, value, ',')) {
            stringstream valueStream(value);
            if (key == "populationSize") valueStream >> _populationSize;
            else if (key == "happiness") valueStream >> _happiness;
            else if (key == "health") valueStream >> _health;
        }
    }
}

void Population::handleEvent(const string& eventType) {
    if (eventType == "Disease") {
        _health -= 0.2;
        try {
            reducePopulation(getRandom(50, 200));
        }
        catch (const PopulationException& e) {
            cout << RED << "Error: " << e.what() << RESET << endl;
            _populationSize = 0;
        }
    }
    else if (eventType == "Famine") {
        _happiness -= 0.2;
    }
    if (_populationSize < 0) _populationSize = 0;
    _health = max(0.0, min(1.0, _health));
}

string Population::getStatus() const {
    stringstream ss;
    ss << CYAN << "Population: Size=" << _populationSize << ", Happiness=" << _happiness * 100 << "%, Health=" << _health * 100 << "%\n" << RESET;
    return ss.str();
}

int Population::getPopulationSize() const { return _populationSize; }

void Population::reducePopulation(int amount) {
    if (amount > _populationSize) {
        throw PopulationException("Cannot reduce population by " + to_string(amount) + "; only " + to_string(_populationSize) + " available.");
    }
    _populationSize -= amount;
    if (_populationSize < 0) _populationSize = 0;
}
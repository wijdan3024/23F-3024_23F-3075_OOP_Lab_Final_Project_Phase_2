#include "KingdomGame.h"

Market::Market(int id) : _kingdomId(id) {
    for (int i = 0; i < MAX_KINGDOMS; i++) _embargoes[i] = false;
}

void Market::update() {}

void Market::save(ofstream& out) {}

void Market::load(ifstream& in) {}

void Market::handleEvent(const string& eventType) {}

string Market::getStatus() const {
    return "Market: Active\n";
}

bool Market::trade(int buyerId, const string& resource, int quantity, int price, Resources<int>* sellerRes, Resources<int>* buyerRes, Economy* sellerEcon, Economy* buyerEcon) {
    if (sellerRes->getResource(resource) >= quantity && buyerEcon->getGoldAmount() >= price) {
        sellerRes->adjustResource(resource, -quantity);
        buyerRes->adjustResource(resource, quantity);
        *sellerEcon += price;
        *buyerEcon += (-price);
        return true;
    }
    return false;
}

bool Market::smuggle(int buyerId, const string& resource, int quantity, int price, Resources<int>* sellerRes, Resources<int>* buyerRes, Economy* sellerEcon, Economy* buyerEcon, SocialStructure* social) {
    return trade(buyerId, resource, quantity, price, sellerRes, buyerRes, sellerEcon, buyerEcon);
}

bool Market::addEmbargo(int id) {
    _embargoes[id] = true;
    return true;
}
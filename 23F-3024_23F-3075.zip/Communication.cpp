#include "KingdomGame.h"

Communication::Communication() : _messages("") {}

void Communication::update() {}

void Communication::save(ofstream& out) {
    out << "messages:" << _messages << "\n";
}

void Communication::load(ifstream& in) {
    string line;
    getline(in, line);
    _messages = line;
}

void Communication::handleEvent(const string& eventType) {}

string Communication::getStatus() const {
    return "Communication: " + _messages + "\n";
}

bool Communication::sendMessage(int senderId, int recipientId, const string& message) {
    _messages += "From " + to_string(senderId) + " to " + to_string(recipientId) + ": " + message + "\n";
    return true;
}
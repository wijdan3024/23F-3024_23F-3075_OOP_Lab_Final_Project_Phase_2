#include "KingdomGame.h"

Banking::Banking() : _loanAmount(0.0), _corruption(0.1) {}

void Banking::update() {}

void Banking::save(ofstream& out) {
    out << "loanAmount:" << _loanAmount << "\n";
}

void Banking::load(ifstream& in) {
    in >> _loanAmount;
}

void Banking::handleEvent(const string& eventType) {}

string Banking::getStatus() const {
    return "Banking: Loan=" + to_string(_loanAmount) + "\n";
}

bool Banking::takeLoan(double amount, Economy* economy) {
    if (economy) {
        _loanAmount += amount;
        *economy += amount;
        return true;
    }
    return false;
}

void Banking::audit() {
    _corruption = max(0.0, _corruption - 0.05);
}
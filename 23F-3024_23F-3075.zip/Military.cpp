#include "KingdomGame.h"

Military::Military(Population* pop, Resources<int>* res) : _soldiers(100), _morale(0.8), _population(pop), _resources(res) {}

void Military::update() {}

void Military::save(ofstream& out) {
    out << "soldiers:" << _soldiers << "\n";
}

void Military::load(ifstream& in) {
    in >> _soldiers;
}

void Military::handleEvent(const string& eventType) {}

string Military::getStatus() const {
    return "Military: Soldiers=" + to_string(_soldiers) + "\n";
}

bool Military::recruit(int count) {
    if (_population && _population->getPopulationSize() / 10 >= count) {
        _soldiers += count;
        try {
            _population->reducePopulation(count * 10);
        }
        catch (const PopulationException& e) {
            cout << RED << "Error: " << e.what() << RESET << endl;
            return false;
        }
        return true;
    }
    return false;
}

bool Military::paySoldiers(Economy* economy) {
    if (economy && economy->getGoldAmount() >= _soldiers * 10) {
        *economy += (-_soldiers * 10);
        return true;
    }
    return false;
}

bool Military::attack(Military* target, bool isBetrayal, SocialStructure* social, Resources<int>* res) {
    return _soldiers > target->_soldiers;
}

void Military::adjustMorale(double delta) {
    _morale = max(0.0, min(1.0, _morale + delta));
}
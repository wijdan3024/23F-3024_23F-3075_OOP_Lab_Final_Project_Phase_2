#include "KingdomGame.h"

Economy::Economy() : _gold(1000.0), _taxRate(BASE_TAX_RATE) {}

void Economy::update() {
    _gold += _taxRate * 1000;
}

void Economy::save(ofstream& out) {
    out << "gold:" << _gold << "\n";
}

void Economy::load(ifstream& in) {
    in >> _gold;
}

void Economy::handleEvent(const string& eventType) {}

string Economy::getStatus() const {
    return "Economy: Gold=" + to_string(_gold) + "\n";
}

void Economy::setTaxRate(double rate) {
    _taxRate = rate;
}

double Economy::getGoldAmount() const {
    return _gold;
}

void Economy::adjustGold(double amount) {
    _gold += amount;
}

Economy& Economy::operator+=(double amount) {
    _gold += amount;
    return *this;
}
#include "KingdomGame.h"

// Utility function implementation
int getRandom(int min, int max) {
    return min + (rand() % (max - min + 1));
}

Kingdom::Kingdom(int kingdomId) : _turn(0), _stability(0.8), _historyCount(0), _kingdomId(kingdomId) {
    for (int i = 0; i < 10; i++) _history[i] = nullptr;
    _socialStructure = new SocialStructure();
    _population = new Population();
    _resources = new Resources<int>();
    _economy = new Economy();
    _military = new Military(_population, _resources);
    _politics = new Politics(_socialStructure, _military);
    _banking = new Banking();
    _eventManager = new EventManager();
    _communication = new Communication();
    _alliance = new Alliance(_kingdomId);
    _market = new Market(_kingdomId);
    _map = new Map(_kingdomId);
}

Kingdom::~Kingdom() {
    for (int i = 0; i < _historyCount; i++) delete _history[i];
    delete _socialStructure;
    delete _population;
    delete _military;
    delete _politics;
    delete _economy;
    delete _banking;
    delete _resources;
    delete _eventManager;
    delete _communication;
    delete _alliance;
    delete _market;
    delete _map;
}

void Kingdom::logScore() {
    ofstream out("GAME_SCORE.txt", ios::app);
    if (out.is_open()) {
        out << "Kingdom " << _kingdomId << " Turn " << _turn << ": Stability=" << _stability * 100 << "%, "
            << "FoodConsumed=" << (MAX_POPULATION - _population->getPopulationSize()) / 10 << ", "
            << "GoldSpent=" << _economy->getGoldAmount() << "\n";
        out.close();
    }
}

void Kingdom::addToHistory(const string& action, const string& details) {
    if (_historyCount < 10) {
        _history[_historyCount] = new TurnHistory(_turn, action, details);
        _historyCount++;
    }
    else {
        delete _history[0];
        for (int i = 0; i < 9; i++) _history[i] = _history[i + 1];
        _history[9] = new TurnHistory(_turn, action, details);
    }
    ofstream out("Session_Game_Log.txt", ios::app);
    if (out.is_open()) {
        out << "Kingdom " << _kingdomId << " Turn " << _turn << ": " << action << " - " << details << "\n";
        out.close();
    }
}

void Kingdom::update() {
    _turn++;
    _resources->update();
    _population->update();
    _economy->setTaxRate(_politics->getTaxPolicy());
    _economy->update();
    _military->adjustMorale(_politics->getMilitarySupport());
    _military->update();
    _banking->update();
    _socialStructure->update();
    _politics->update();
    _eventManager->update();
    _communication->update();
    _alliance->update();
    _market->update();
    _map->update();

    if (getRandom(1, 100) < 20) {
        string event = _eventManager->getRandomEvent();
        if (!event.empty()) {
            addToHistory("Event", event + " occurred");
            _socialStructure->handleEvent(event);
            _population->handleEvent(event);
            _military->handleEvent(event);
            _politics->handleEvent(event);
            _economy->handleEvent(event);
            _banking->handleEvent(event);
            _resources->handleEvent(event);
        }
    }

    _stability = 1.0 - _socialStructure->getTotalUnrest();
    if (_stability < 0.2) {
        cout << RED << "Kingdom " << _kingdomId << " has collapsed due to high unrest!\n" << RESET;
        addToHistory("Game Over", "Kingdom collapsed due to high unrest");
        exit(0);
    }

    logScore();
}

void Kingdom::saveGame() {
    ofstream out("GAME_save_" + to_string(_kingdomId) + ".txt");
    if (!out.is_open()) {
        cout << RED << "Error: Could not save game for Kingdom " << _kingdomId << ".\n" << RESET;
        return;
    }
    _socialStructure->save(out);
    _population->save(out);
    _military->save(out);
    _politics->save(out);
    _economy->save(out);
    _banking->save(out);
    _resources->save(out);
    _communication->save(out);
    _alliance->save(out);
    _market->save(out);
    _map->save(out);
    out.close();
    addToHistory("Save Game", "Game saved for Kingdom " + to_string(_kingdomId));
}

void Kingdom::loadGame() {
    ifstream in("GAME_save_" + to_string(_kingdomId) + ".txt");
    if (!in.is_open()) {
        cout << RED << "Error: Could not load game for Kingdom " << _kingdomId << ".\n" << RESET;
        return;
    }
    _socialStructure->load(in);
    in.clear(); in.seekg(0);
    _population->load(in);
    in.clear(); in.seekg(0);
    _military->load(in);
    in.clear(); in.seekg(0);
    _politics->load(in);
    in.clear(); in.seekg(0);
    _economy->load(in);
    in.clear(); in.seekg(0);
    _banking->load(in);
    in.clear(); in.seekg(0);
    _resources->load(in);
    in.clear(); in.seekg(0);
    _communication->load(in);
    in.clear(); in.seekg(0);
    _alliance->load(in);
    in.clear(); in.seekg(0);
    _market->load(in);
    in.clear(); in.seekg(0);
    _map->load(in);
    in.close();
    addToHistory("Load Game", "Game loaded for Kingdom " + to_string(_kingdomId));
}

void Kingdom::displayStatus() {
    cout << "Kingdom " << _kingdomId << " Turn: " << _turn << "\n";
    cout << (_stability < 0.5 ? RED : RESET) << "Stability: " << _stability * 100 << "%\n" << RESET;
    cout << _socialStructure->getStatus();
    cout << _population->getStatus();
    cout << _military->getStatus();
    cout << _politics->getStatus();
    cout << _economy->getStatus();
    cout << _banking->getStatus();
    cout << _resources->getStatus();
    cout << _communication->getStatus();
    cout << _alliance->getStatus();
    cout << _market->getStatus();
    cout << _map->getStatus();

    cout << CYAN << "Recent Turn History (Last " << _historyCount << " Actions):\n" << RESET;
    for (int i = 0; i < _historyCount; i++) {
        if (_history[i]) {
            cout << "  Turn " << _history[i]->turn << ": " << _history[i]->action << " - " << _history[i]->details << "\n";
        }
    }
    addToHistory("View Status", "Displayed kingdom status");
}

void Kingdom::displayLeaderPersonality() {
    cout << CYAN << "Leader Personality: " << _politics->getLeaderPersonality() << "\n" << RESET;
    addToHistory("View Leader", "Displayed leader personality");
}

int Kingdom::getKingdomId() const { return _kingdomId; }
Military* Kingdom::getMilitary() { return _military; }
SocialStructure* Kingdom::getSocialStructure() { return _socialStructure; }
Resources<int>* Kingdom::getResources() { return _resources; }
Economy* Kingdom::getEconomy() { return _economy; }
Communication* Kingdom::getCommunication() { return _communication; }
Alliance* Kingdom::getAlliance() { return _alliance; }
Market* Kingdom::getMarket() { return _market; }
Map* Kingdom::getMap() { return _map; }
Population* Kingdom::getPopulation() { return _population; }
Banking* Kingdom::getBanking() { return _banking; }
int Kingdom::getTurn() const { return _turn; }
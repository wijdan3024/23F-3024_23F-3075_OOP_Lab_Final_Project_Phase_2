#include "KingdomGame.h"

Alliance::Alliance(int id) : _kingdomId(id) {
    for (int i = 0; i < MAX_KINGDOMS; i++) _allied[i] = false;
}

void Alliance::update() {}

void Alliance::save(ofstream& out) {}

void Alliance::load(ifstream& in) {}

void Alliance::handleEvent(const string& eventType) {}

string Alliance::getStatus() const {
    return "Alliance: None\n";
}

bool Alliance::proposeTreaty(int otherId, const string& type) {
    _allied[otherId] = true;
    return true;
}

bool Alliance::breakTreaty(int otherId, SocialStructure* social) {
    _allied[otherId] = false;
    return true;
}

bool Alliance::isAllied(int id) const {
    return _allied[id];
}
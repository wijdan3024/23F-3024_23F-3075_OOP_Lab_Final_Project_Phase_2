#include "KingdomGame.h"

EventManager::EventManager() {}

void EventManager::update() {}

void EventManager::save(ofstream& out) {}

void EventManager::load(ifstream& in) {}

void EventManager::handleEvent(const string& eventType) {}

string EventManager::getStatus() const {
    return "EventManager: No events\n";
}

string EventManager::getRandomEvent() {
    return getRandom(0, 1) ? "Disease" : "Famine";
}
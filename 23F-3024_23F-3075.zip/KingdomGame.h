#ifndef KINGDOM_GAME_H
#define KINGDOM_GAME_H

#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <sstream>

using namespace std;

// Constants
const int MAX_POPULATION = 10000;
const double BASE_TAX_RATE = 0.1;
const int BASE_RESOURCE_PRODUCTION = 50;
const int MAX_KINGDOMS = 4;
const int GRID_SIZE = 5;

// Color codes
const string RESET = "\033[0m";
const string RED = "\033[31m";
const string GREEN = "\033[32m";
const string CYAN = "\033[36m";
const string MAGENTA = "\033[35m";

// Utility function
int getRandom(int min, int max);

// TurnHistory structure
struct TurnHistory {
    int turn;
    string action;
    string details;
    TurnHistory(int t, const string& a, const string& d);
};

// Abstract base class
class KingdomComponent {
public:
    virtual void update() = 0;
    virtual void save(ofstream& out) = 0;
    virtual void load(ifstream& in) = 0;
    virtual void handleEvent(const string& eventType) = 0;
    virtual string getStatus() const = 0;
    virtual ~KingdomComponent() {}
};

// Custom exception for Population
class PopulationException : public exception {
private:
    string message;
public:
    PopulationException(const string& msg);
    const char* what() const noexcept override;
};

// Population class
class Population : public KingdomComponent {
private:
    int _populationSize;
    double _happiness;
    double _health;
public:
    Population();
    void update() override;
    void save(ofstream& out) override;
    void load(ifstream& in) override;
    void handleEvent(const string& eventType) override;
    string getStatus() const override;
    int getPopulationSize() const;
    void reducePopulation(int amount);
};

// SocialStructure class
class SocialStructure : public KingdomComponent {
private:
    double _unrest;
public:
    SocialStructure();
    void update() override;
    void save(ofstream& out) override;
    void load(ifstream& in) override;
    void handleEvent(const string& eventType) override;
    string getStatus() const override;
    double getTotalUnrest() const;
};

// Templated Resources class
template <typename T>
class Resources : public KingdomComponent {
private:
    T _food, _wood, _stone;
public:
    Resources();
    void update() override;
    void save(ofstream& out) override;
    void load(ifstream& in) override;
    void handleEvent(const string& eventType) override;
    string getStatus() const override;
    T getResource(const string& type) const;
    void adjustResource(const string& type, T amount);
};

// Economy class
class Economy : public KingdomComponent {
private:
    double _gold, _taxRate;
public:
    Economy();
    void update() override;
    void save(ofstream& out) override;
    void load(ifstream& in) override;
    void handleEvent(const string& eventType) override;
    string getStatus() const override;
    void setTaxRate(double rate);
    double getGoldAmount() const;
    void adjustGold(double amount);
    Economy& operator+=(double amount);
};

// Military class
class Military : public KingdomComponent {
private:
    int _soldiers;
    double _morale;
    Population* _population;
    Resources<int>* _resources;
public:
    Military(Population* pop, Resources<int>* res);
    void update() override;
    void save(ofstream& out) override;
    void load(ifstream& in) override;
    void handleEvent(const string& eventType) override;
    string getStatus() const override;
    bool recruit(int count);
    bool paySoldiers(Economy* economy);
    bool attack(Military* target, bool isBetrayal, SocialStructure* social, Resources<int>* res);
    void adjustMorale(double delta);
};

// Politics class
class Politics : public KingdomComponent {
private:
    double _taxPolicy, _militarySupport;
    string _leaderPersonality;
public:
    Politics(SocialStructure* social, Military* military);
    void update() override;
    void save(ofstream& out) override;
    void load(ifstream& in) override;
    void handleEvent(const string& eventType) override;
    string getStatus() const override;
    double getTaxPolicy() const;
    double getMilitarySupport() const;
    string getLeaderPersonality() const;
};

// Banking class
class Banking : public KingdomComponent {
private:
    double _loanAmount, _corruption;
public:
    Banking();
    void update() override;
    void save(ofstream& out) override;
    void load(ifstream& in) override;
    void handleEvent(const string& eventType) override;
    string getStatus() const override;
    bool takeLoan(double amount, Economy* economy);
    void audit();
};

// EventManager class
class EventManager : public KingdomComponent {
public:
    EventManager();
    void update() override;
    void save(ofstream& out) override;
    void load(ifstream& in) override;
    void handleEvent(const string& eventType) override;
    string getStatus() const override;
    string getRandomEvent();
};

// Communication class
class Communication : public KingdomComponent {
private:
    string _messages;
public:
    Communication();
    void update() override;
    void save(ofstream& out) override;
    void load(ifstream& in) override;
    void handleEvent(const string& eventType) override;
    string getStatus() const override;
    bool sendMessage(int senderId, int recipientId, const string& message);
};

// Alliance class
class Alliance : public KingdomComponent {
private:
    int _kingdomId;
    bool _allied[MAX_KINGDOMS];
public:
    Alliance(int id);
    void update() override;
    void save(ofstream& out) override;
    void load(ifstream& in) override;
    void handleEvent(const string& eventType) override;
    string getStatus() const override;
    bool proposeTreaty(int otherId, const string& type);
    bool breakTreaty(int otherId, SocialStructure* social);
    bool isAllied(int id) const;
};

// Market class
class Market : public KingdomComponent {
private:
    int _kingdomId;
    bool _embargoes[MAX_KINGDOMS];
public:
    Market(int id);
    void update() override;
    void save(ofstream& out) override;
    void load(ifstream& in) override;
    void handleEvent(const string& eventType) override;
    string getStatus() const override;
    bool trade(int buyerId, const string& resource, int quantity, int price, Resources<int>* sellerRes, Resources<int>* buyerRes, Economy* sellerEcon, Economy* buyerEcon);
    bool smuggle(int buyerId, const string& resource, int quantity, int price, Resources<int>* sellerRes, Resources<int>* buyerRes, Economy* sellerEcon, Economy* buyerEcon, SocialStructure* social);
    bool addEmbargo(int id);
};

// Map class
class Map : public KingdomComponent {
private:
    int _kingdomId, _x, _y;
public:
    Map(int id);
    void update() override;
    void save(ofstream& out) override;
    void load(ifstream& in) override;
    void handleEvent(const string& eventType) override;
    string getStatus() const override;
    bool move(int newX, int newY);
    int getX() const;
    int getY() const;
    bool isAdjacent(int x, int y) const;
};

// Kingdom class
class Kingdom {
private:
    SocialStructure* _socialStructure;
    Population* _population;
    Military* _military;
    Politics* _politics;
    Economy* _economy;
    Banking* _banking;
    Resources<int>* _resources;
    EventManager* _eventManager;
    Communication* _communication;
    Alliance* _alliance;
    Market* _market;
    Map* _map;
    int _turn;
    double _stability;
    TurnHistory* _history[10];
    int _historyCount;
    int _kingdomId;

    void logScore();

public:
    Kingdom(int kingdomId);
    ~Kingdom();
    void addToHistory(const string& action, const string& details);
    void update();
    void saveGame();
    void loadGame();
    void displayStatus();
    void displayLeaderPersonality();
    int getKingdomId() const;
    Military* getMilitary();
    SocialStructure* getSocialStructure();
    Resources<int>* getResources();
    Economy* getEconomy();
    Communication* getCommunication();
    Alliance* getAlliance();
    Market* getMarket();
    Map* getMap();
    Population* getPopulation();
    Banking* getBanking();
    int getTurn() const;
};

#endif // KINGDOM_GAME_H
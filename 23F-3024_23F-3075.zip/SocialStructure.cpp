#include "KingdomGame.h"

SocialStructure::SocialStructure() : _unrest(0.2) {}

void SocialStructure::update() {}

void SocialStructure::save(ofstream& out) {
    out << "unrest:" << _unrest << "\n";
}

void SocialStructure::load(ifstream& in) {
    in >> _unrest;
}

void SocialStructure::handleEvent(const string& eventType) {}

string SocialStructure::getStatus() const {
    return "Social: Unrest=" + to_string(_unrest * 100) + "%\n";
}

double SocialStructure::getTotalUnrest() const { return _unrest; }